"""
base
====

Abstract base class for all demand models in the SOBUSA project.
"""

from abc import ABC, abstractmethod
from typing import Any

import numpy as np
import optuna
import pandas as pd

__all__ = ["BaseDemandModel"]


class BaseDemandModel(ABC):
    """Universal abstract base class for all demand models."""

    def __init__(self, **kwargs: Any) -> None:
        self.params = kwargs
        self.is_fitted = False
        self.is_valid = False

    @staticmethod
    @abstractmethod
    def suggest_params(trial: optuna.Trial) -> dict[str, Any]:
        """Defines the hyperparameter search space for Optuna."""

    @property
    @abstractmethod
    def context_length(self) -> int:
        """Returns the number of past observations needed as context."""

    @abstractmethod
    def fit(
        self,
        X_train: pd.DataFrame,
        y_train: np.ndarray,
        X_val: pd.DataFrame | None = None,
        y_val: np.ndarray | None = None,
    ) -> None:
        """Fits the model on tabular features.

        Must set ``self.is_fitted = True`` and ``self.is_valid = True``
        on success.
        """

    @abstractmethod
    def forecast(
        self,
        X_seq: pd.DataFrame,
        y_seq: np.ndarray | None = None,
        save_dir: str | None = None,
        extra_metadata: dict | None = None,
        debug: bool = False,
    ) -> np.ndarray:
        """Generates demand predictions for the given feature matrix."""

    @abstractmethod
    def get_diagnostics(self) -> dict[str, Any]:
        """Returns the diagnostic data of the fitted model.

        Must include at least:

        - ``converged`` (bool): whether training succeeded.
        - ``epochs_run`` (int): boosting rounds or epochs (0 if N/A).
        """