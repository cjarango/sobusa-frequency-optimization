"""
lgbm_tweedie_wrapper
====================

LightGBM wrapper with Tweedie loss for tabular passenger-demand
forecasting. Exposes two clean prediction interfaces returning ``np.ndarray``:
  - ``predict_in_sample``: static evaluation on the fitted training set.
  - ``forecast``: static inference or block-wise rolling refit with a sliding window.
"""

import json
import time
from pathlib import Path
from typing import Any

try:
    from datetime import UTC, datetime
except ImportError:
    from datetime import datetime, timezone

    UTC = timezone.utc

import lightgbm as lgb
import numpy as np
import optuna
import pandas as pd
from models.base import BaseDemandModel

__all__ = ["LightGBMTweedieWrapper"]

_NULLABLE_INT_DTYPES = (
    "Int64", "UInt64",
    "Int32", "UInt32",
    "Int16", "UInt16",
    "Int8", "UInt8",
)


class LightGBMTweedieWrapper(BaseDemandModel):
    """LightGBM with Tweedie loss for passenger demand."""

    @staticmethod
    def suggest_params(trial: optuna.Trial) -> dict:
        return {
            "tweedie_variance_power": trial.suggest_float(
                "tweedie_variance_power", 1.05, 1.95, step=0.05
            ),
            "num_leaves": trial.suggest_int("num_leaves", 15, 255, log=True),
            "learning_rate": trial.suggest_float(
                "learning_rate", 1e-3, 0.3, log=True
            ),
            "min_data_in_leaf": trial.suggest_int(
                "min_data_in_leaf", 20, 500, log=True
            ),
            "feature_fraction": trial.suggest_float(
                "feature_fraction", 0.5, 1.0, step=0.05
            ),
            "bagging_fraction": trial.suggest_float(
                "bagging_fraction", 0.5, 1.0, step=0.05
            ),
            "bagging_freq": trial.suggest_int("bagging_freq", 1, 10),
            "lambda_l1": trial.suggest_float("lambda_l1", 1e-8, 10.0, log=True),
            "lambda_l2": trial.suggest_float("lambda_l2", 1e-8, 10.0, log=True),
            "min_sum_hessian_in_leaf": trial.suggest_float(
                "min_sum_hessian_in_leaf", 1e-3, 10.0, log=True
            ),
        }

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)

        self.tweedie_variance_power = float(kwargs.get("tweedie_variance_power", 1.5))
        self.num_leaves = int(kwargs.get("num_leaves", 31))
        self.learning_rate = float(kwargs.get("learning_rate", 0.05))
        self.min_data_in_leaf = int(kwargs.get("min_data_in_leaf", 20))
        self.feature_fraction = float(kwargs.get("feature_fraction", 0.9))
        self.bagging_fraction = float(kwargs.get("bagging_fraction", 0.9))
        self.bagging_freq = int(kwargs.get("bagging_freq", 5))
        self.lambda_l1 = float(kwargs.get("lambda_l1", 0.0))
        self.lambda_l2 = float(kwargs.get("lambda_l2", 0.0))
        self.min_sum_hessian_in_leaf = float(
            kwargs.get("min_sum_hessian_in_leaf", 1e-3)
        )
        self.n_estimators = int(kwargs.get("n_estimators", 2000))
        self.early_stopping_rounds = int(kwargs.get("early_stopping_rounds", 100))
        self.inner_val_frac = float(kwargs.get("inner_val_frac", 0.0))
        self.seed = int(kwargs.get("seed", 42))
        self.num_threads = kwargs.get("num_threads", None)
        if self.num_threads is not None:
            self.num_threads = int(self.num_threads)

        self._validate_hyperparameters()

        self.model: lgb.Booster | None = None
        self.feature_names: list[str] | None = None
        self.best_iteration: int | None = None
        self.evals_result_: dict = {}

        self.X_train_history: pd.DataFrame | None = None
        self.y_train_history: np.ndarray | None = None
        self.rolling_folds_: list[dict[str, Any]] = []

        self.converged: bool = False

    def _validate_hyperparameters(self) -> None:
        if not 1.0 < self.tweedie_variance_power < 2.0:
            raise ValueError(
                "'tweedie_variance_power' must be in (1.0, 2.0). "
                f"Got {self.tweedie_variance_power}."
            )
        if self.num_leaves < 2:
            raise ValueError(f"'num_leaves' must be >= 2. Got {self.num_leaves}.")
        if self.learning_rate <= 0:
            raise ValueError(
                f"'learning_rate' must be > 0. Got {self.learning_rate}."
            )
        if self.min_data_in_leaf < 1:
            raise ValueError(
                f"'min_data_in_leaf' must be >= 1. Got {self.min_data_in_leaf}."
            )
        if not 0.0 < self.feature_fraction <= 1.0:
            raise ValueError(
                f"'feature_fraction' must be in (0, 1]. Got {self.feature_fraction}."
            )
        if not 0.0 < self.bagging_fraction <= 1.0:
            raise ValueError(
                f"'bagging_fraction' must be in (0, 1]. Got {self.bagging_fraction}."
            )
        if self.bagging_freq < 0:
            raise ValueError(
                f"'bagging_freq' must be >= 0. Got {self.bagging_freq}."
            )
        if self.lambda_l1 < 0:
            raise ValueError(f"'lambda_l1' must be >= 0. Got {self.lambda_l1}.")
        if self.lambda_l2 < 0:
            raise ValueError(f"'lambda_l2' must be >= 0. Got {self.lambda_l2}.")
        if self.min_sum_hessian_in_leaf < 0:
            raise ValueError(
                "'min_sum_hessian_in_leaf' must be >= 0. "
                f"Got {self.min_sum_hessian_in_leaf}."
            )
        if self.n_estimators < 1:
            raise ValueError(
                f"'n_estimators' must be >= 1. Got {self.n_estimators}."
            )
        if self.early_stopping_rounds < 0:
            raise ValueError(
                "'early_stopping_rounds' must be >= 0. "
                f"Got {self.early_stopping_rounds}."
            )
        if not 0.0 <= self.inner_val_frac < 1.0:
            raise ValueError(
                f"'inner_val_frac' must be in [0, 1). Got {self.inner_val_frac}."
            )
        if self.num_threads is not None and self.num_threads < 1:
            raise ValueError(
                f"'num_threads' must be >= 1 or None. Got {self.num_threads}."
            )

    @property
    def context_length(self) -> int:
        return 0

    def _fit_booster(
        self,
        X_train: pd.DataFrame,
        y_train: np.ndarray,
        X_val: pd.DataFrame | None = None,
        y_val: np.ndarray | None = None,
        embargo: int = 0,
    ) -> tuple[lgb.Booster, int, dict]:
        """Trains a LightGBM Booster. Splits inner validation if ``inner_val_frac > 0``."""
        assert self.feature_names is not None
        y_tr_arr = np.asarray(y_train, dtype=np.float64)

        if X_val is None and self.inner_val_frac > 0.0:
            n = len(X_train)
            n_val = max(1, int(n * self.inner_val_frac))
            n_fit = n - n_val - embargo
            if n_fit >= 1:
                X_val = X_train.iloc[n - n_val :]
                y_val = y_tr_arr[n - n_val :]
                X_train = X_train.iloc[:n_fit]
                y_tr_arr = y_tr_arr[:n_fit]

        X_tr_prep = self._prepare_features(X_train)[self.feature_names]
        params = self._build_params()
        train_set = lgb.Dataset(
            X_tr_prep,
            label=y_tr_arr,
            feature_name=self.feature_names,
            free_raw_data=False,
        )

        valid_sets: list[lgb.Dataset] = [train_set]
        valid_names: list[str] = ["train"]
        callbacks: list = []

        if X_val is not None and y_val is not None:
            X_va_prep = self._prepare_features(X_val)[self.feature_names]
            y_va_prep = np.asarray(y_val, dtype=np.float64)
            valid_sets.append(
                lgb.Dataset(
                    X_va_prep,
                    label=y_va_prep,
                    reference=train_set,
                    feature_name=self.feature_names,
                    free_raw_data=False,
                )
            )
            valid_names.append("valid")
            if self.early_stopping_rounds > 0:
                callbacks.append(
                    lgb.early_stopping(self.early_stopping_rounds, verbose=False)
                )

        evals_res: dict = {}
        callbacks.append(lgb.record_evaluation(evals_res))

        booster = lgb.train(
            params,
            train_set,
            num_boost_round=self.n_estimators,
            valid_sets=valid_sets,
            valid_names=valid_names,
            callbacks=callbacks,
        )
        best_iter = booster.best_iteration or booster.current_iteration()
        if best_iter <= 0:
            raise RuntimeError("LightGBM produced a model with zero trees.")
        return booster, best_iter, evals_res

    def fit(
        self,
        X_train: pd.DataFrame,
        y_train: np.ndarray,
        X_val: pd.DataFrame | None = None,
        y_val: np.ndarray | None = None,
    ) -> None:
        """Fits the model on the training set and stores history."""
        self._validate_fit_inputs(X_train, y_train, X_val, y_val)

        self.feature_names = list(X_train.columns)
        self.X_train_history = X_train.copy()
        self.y_train_history = np.asarray(y_train, dtype=np.float64).copy()

        try:
            booster, best_iter, evals_res = self._fit_booster(
                X_train=X_train,
                y_train=y_train,
                X_val=X_val,
                y_val=y_val,
            )
            self.model = booster
            self.best_iteration = best_iter
            self.evals_result_ = evals_res
            self.converged = True
            self.is_fitted = True
            self.is_valid = True
        except Exception as e:
            self.is_fitted = False
            self.is_valid = False
            raise RuntimeError(f"LightGBM fitting failed: {e}") from e

    def predict_in_sample(self, X: pd.DataFrame | None = None) -> np.ndarray:
        """Returns static in-sample predictions ``np.ndarray`` using the fitted booster."""
        if not self.is_fitted or self.model is None or self.feature_names is None:
            raise RuntimeError("Model must be fitted before in-sample prediction.")

        if X is None:
            if self.X_train_history is None:
                raise RuntimeError("No stored training history available.")
            X_eval = self.X_train_history
        else:
            if not isinstance(X, pd.DataFrame):
                raise TypeError("X must be a pandas DataFrame.")
            missing = set(self.feature_names) - set(X.columns)
            if missing:
                raise ValueError(
                    f"X is missing {len(missing)} feature(s): {sorted(missing)}."
                )
            X_eval = X

        X_prep = self._prepare_features(X_eval)[self.feature_names]
        return np.asarray(
            self.model.predict(X_prep, num_iteration=self.best_iteration),
            dtype=np.float64,
        )

    def forecast(
        self,
        X_seq: pd.DataFrame,
        y_seq: np.ndarray | None = None,
        window: int | None = None,
        embargo: int = 0,
        step_size: int | None = None,
        n_splits: int | None = None,
        start_fold: int = 0,
        on_fold_end: Any = None,
        save_dir: str | None = None,
        extra_metadata: dict | None = None,
        debug: bool = False,
    ) -> np.ndarray:
        """Generates out-of-sample predictions ``np.ndarray``.

        - Static mode (when ``y_seq`` is None, or both ``step_size`` and ``n_splits``
          are None): predicts directly with the already-fitted booster.
        - Rolling mode: partitions ``X_seq`` into blocks (via ``n_splits`` or
          ``step_size``), slices ``window`` historical rows ending at
          ``val_start - embargo``, fits a fresh booster, and predicts each block.
        """
        if not self.is_fitted or self.model is None or self.feature_names is None:
            raise RuntimeError("Model must be fitted before forecasting.")
        if not isinstance(X_seq, pd.DataFrame):
            raise TypeError("X_seq must be a pandas DataFrame.")

        missing = set(self.feature_names) - set(X_seq.columns)
        if missing:
            raise ValueError(
                f"X_seq is missing {len(missing)} feature(s): {sorted(missing)}."
            )

        if y_seq is not None and len(y_seq) != len(X_seq):
            raise ValueError(
                f"y_seq has length {len(y_seq)} but X_seq has {len(X_seq)} rows."
            )

        # Static inference
        if y_seq is None or (step_size is None and n_splits is None):
            X_prep = self._prepare_features(X_seq)[self.feature_names]
            preds = np.asarray(
                self.model.predict(X_prep, num_iteration=self.best_iteration),
                dtype=np.float64,
            )
            if debug:
                print(
                    f"[DEBUG] static n_rows={len(preds)} "
                    f"mean={preds.mean():.3f} max={preds.max():.3f}"
                )
            if save_dir is not None:
                self._save_artifact(
                    save_dir,
                    y_seq,
                    preds,
                    extra_metadata={**(extra_metadata or {}), "forecast_mode": "static"},
                )
            return preds

        # Block-wise rolling refit
        if self.X_train_history is None or self.y_train_history is None:
            raise RuntimeError(
                "Stored training history is required for rolling forecast."
            )

        y_arr = np.asarray(y_seq, dtype=np.float64)
        if not np.isfinite(y_arr).all() or (y_arr < 0).any():
            raise ValueError("y_seq contains NaN, infinite, or negative values.")
        if embargo < 0:
            raise ValueError(f"'embargo' must be >= 0. Got {embargo}.")
        if window is not None and window < 1:
            raise ValueError(f"'window' must be >= 1 or None. Got {window}.")

        n_seq = len(X_seq)
        if n_seq == 0:
            return np.array([], dtype=np.float64)

        if n_splits is not None:
            if n_splits < 1:
                raise ValueError(f"'n_splits' must be >= 1. Got {n_splits}.")
            block_len = n_seq // n_splits
            if block_len <= 0:
                raise ValueError(
                    f"X_seq length ({n_seq}) is smaller than n_splits ({n_splits})."
                )
            slices = [
                (
                    i * block_len,
                    (i + 1) * block_len if i < n_splits - 1 else n_seq,
                )
                for i in range(n_splits)
            ]
        else:
            assert step_size is not None
            if step_size < 1:
                raise ValueError(f"'step_size' must be >= 1. Got {step_size}.")
            slices = [
                (start, min(start + step_size, n_seq))
                for start in range(0, n_seq, step_size)
            ]

        if not 0 <= start_fold <= len(slices):
            raise ValueError(
                f"'start_fold' must be in [0, {len(slices)}]. Got {start_fold}."
            )

        X_hist = pd.concat(
            [self.X_train_history[self.feature_names], X_seq[self.feature_names]],
            axis=0,
        )
        y_hist = np.concatenate([self.y_train_history, y_arr])
        train_offset = len(self.X_train_history)

        self.rolling_folds_ = []
        preds_blocks: list[np.ndarray] = []

        for offset_idx, (start, end) in enumerate(slices[start_fold:]):
            fold_idx = start_fold + offset_idx + 1
            abs_val_start = train_offset + start
            train_end = abs_val_start - embargo
            if train_end < 1:
                raise ValueError(
                    f"Not enough history before fold {fold_idx} with embargo={embargo}."
                )

            train_start = max(0, train_end - window) if window is not None else 0
            X_tr_win = X_hist.iloc[train_start:train_end]
            y_tr_win = y_hist[train_start:train_end]

            t0 = time.time()
            booster, best_iter, _ = self._fit_booster(
                X_train=X_tr_win,
                y_train=y_tr_win,
                embargo=embargo,
            )
            train_time = round(time.time() - t0, 2)

            X_block_prep = self._prepare_features(X_seq.iloc[start:end])[
                self.feature_names
            ]
            block_preds = np.asarray(
                booster.predict(X_block_prep, num_iteration=best_iter),
                dtype=np.float64,
            )
            preds_blocks.append(block_preds)

            fold_info = {
                "fold": fold_idx,
                "train_start_idx": train_start,
                "train_end_idx": train_end,
                "val_start_idx": abs_val_start,
                "val_end_idx": train_offset + end,
                "train_size": len(y_tr_win),
                "val_size": end - start,
                "best_iteration": int(best_iter),
                "train_time_sec": train_time,
                "converged": True,
                "preds": block_preds,
                "y_true": y_arr[start:end],
            }
            self.rolling_folds_.append(fold_info)

            if debug:
                print(
                    f"[DEBUG] rolling fold={fold_idx} rows=[{start}:{end}) "
                    f"train=[{train_start}:{train_end}) best_iter={best_iter}"
                )

            if on_fold_end is not None:
                on_fold_end(fold_info)

        preds = (
            np.concatenate(preds_blocks)
            if preds_blocks
            else np.array([], dtype=np.float64)
        )

        if save_dir is not None and start_fold == 0:
            rolling_meta = {
                "forecast_mode": "rolling",
                "rolling_window": window,
                "rolling_embargo": embargo,
                "n_blocks": len(preds_blocks),
            }
            if extra_metadata:
                rolling_meta.update(extra_metadata)
            self._save_artifact(save_dir, y_arr, preds, extra_metadata=rolling_meta)

        return preds

    def _save_artifact(
        self,
        save_dir: str,
        y_seq: np.ndarray | None,
        predictions: np.ndarray,
        extra_metadata: dict | None = None,
    ) -> Path:
        save_path = Path(save_dir)
        save_path.mkdir(parents=True, exist_ok=True)

        metadata: dict[str, Any] = {
            "class": self.__class__.__name__,
            "seed": self.seed,
            "saved_at_utc": datetime.now(UTC).isoformat(),
            "best_iteration": self.best_iteration,
            "context_length": int(self.context_length),
            "params": {
                "tweedie_variance_power": self.tweedie_variance_power,
                "num_leaves": self.num_leaves,
                "learning_rate": self.learning_rate,
                "min_data_in_leaf": self.min_data_in_leaf,
                "feature_fraction": self.feature_fraction,
                "bagging_fraction": self.bagging_fraction,
                "bagging_freq": self.bagging_freq,
                "lambda_l1": self.lambda_l1,
                "lambda_l2": self.lambda_l2,
                "min_sum_hessian_in_leaf": self.min_sum_hessian_in_leaf,
                "n_estimators": self.n_estimators,
                "early_stopping_rounds": self.early_stopping_rounds,
                "inner_val_frac": self.inner_val_frac,
                "num_threads": self.num_threads,
            },
            "feature_names": self.feature_names,
            "fit_diagnostics": {"converged": self.converged},
            "sizes": {
                "train_history": len(self.y_train_history)
                if self.y_train_history is not None
                else 0,
                "n_features": len(self.feature_names or []),
                "n_predictions": len(predictions),
            },
        }
        if extra_metadata:
            metadata.update(extra_metadata)

        (save_path / "metadata.json").write_text(
            json.dumps(metadata, indent=2, default=str), encoding="utf-8"
        )

        df_dict: dict[str, Any] = {
            "step": range(len(predictions)),
            "y_pred": predictions,
        }
        if y_seq is not None:
            df_dict["y_true"] = np.asarray(y_seq)
        pd.DataFrame(df_dict).to_csv(
            save_path / "walk_forward_predictions.csv", index=False
        )
        return save_path

    def get_diagnostics(self) -> dict:
        if not self.is_fitted or self.model is None:
            return {}

        gain = self.model.feature_importance(importance_type="gain")
        split = self.model.feature_importance(importance_type="split")
        return {
            "converged": self.converged,
            "best_iteration": self.best_iteration,
            "n_features": len(self.feature_names or []),
            "feature_importance_gain": dict(
                zip(self.feature_names or [], gain.tolist())
            ),
            "feature_importance_split": dict(
                zip(self.feature_names or [], split.tolist())
            ),
            "epochs_run": self.best_iteration or 0,
        }

    def get_history(self) -> dict:
        if not self.evals_result_:
            return {"train_loss": [], "val_loss": []}

        train_loss = self.evals_result_.get("train", {}).get("tweedie", [])
        val_loss = self.evals_result_.get("valid", {}).get("tweedie", [])
        return {
            "train_loss": list(train_loss),
            "val_loss": list(val_loss),
        }

    def _build_params(self) -> dict:
        params = {
            "objective": "tweedie",
            "tweedie_variance_power": self.tweedie_variance_power,
            "metric": "tweedie",
            "num_leaves": self.num_leaves,
            "learning_rate": self.learning_rate,
            "min_data_in_leaf": self.min_data_in_leaf,
            "feature_fraction": self.feature_fraction,
            "bagging_fraction": self.bagging_fraction,
            "bagging_freq": self.bagging_freq,
            "lambda_l1": self.lambda_l1,
            "lambda_l2": self.lambda_l2,
            "min_sum_hessian_in_leaf": self.min_sum_hessian_in_leaf,
            "seed": self.seed,
            "feature_fraction_seed": self.seed,
            "bagging_seed": self.seed,
            "verbose": -1,
        }
        if self.num_threads is not None:
            params["num_threads"] = self.num_threads
        return params

    @staticmethod
    def _prepare_features(X: pd.DataFrame) -> pd.DataFrame:
        X = X.copy()
        for col in X.columns:
            if X[col].dtype.name in _NULLABLE_INT_DTYPES:
                X[col] = X[col].astype("float64")
        return X

    def _validate_fit_inputs(
        self,
        X_train: pd.DataFrame,
        y_train: np.ndarray,
        X_val: pd.DataFrame | None,
        y_val: np.ndarray | None,
    ) -> None:
        if not isinstance(X_train, pd.DataFrame):
            raise TypeError("X_train must be a pandas DataFrame.")
        if len(X_train) == 0:
            raise ValueError("X_train is empty.")
        if X_train.shape[1] == 0:
            raise ValueError("X_train must have at least one feature column.")
        if len(set(X_train.columns)) != len(X_train.columns):
            raise ValueError("X_train contains duplicate column names.")

        y_train = np.asarray(y_train, dtype=np.float64)
        if y_train.ndim != 1:
            raise ValueError(f"y_train must be 1-D. Got shape {y_train.shape}.")
        if len(y_train) != len(X_train):
            raise ValueError(
                f"y_train has length {len(y_train)} but X_train has "
                f"{len(X_train)} rows."
            )
        if not np.isfinite(y_train).all():
            raise ValueError("y_train contains NaN or infinite values.")
        if (y_train < 0).any():
            raise ValueError("y_train contains negative values (invalid for Tweedie).")

        if (X_val is None) != (y_val is None):
            raise ValueError(
                "X_val and y_val must be provided together or not at all."
            )

        if X_val is not None and y_val is not None:
            if not isinstance(X_val, pd.DataFrame):
                raise TypeError("X_val must be a pandas DataFrame.")
            y_val = np.asarray(y_val, dtype=np.float64)
            if y_val.ndim != 1:
                raise ValueError(f"y_val must be 1-D. Got shape {y_val.shape}.")
            if len(y_val) != len(X_val):
                raise ValueError(
                    f"y_val has length {len(y_val)} but X_val has "
                    f"{len(X_val)} rows."
                )
            if not np.isfinite(y_val).all():
                raise ValueError("y_val contains NaN or infinite values.")
            if (y_val < 0).any():
                raise ValueError("y_val contains negative values (invalid for Tweedie).")
            if set(X_train.columns) != set(X_val.columns):
                raise ValueError(
                    "X_train and X_val must share the same feature columns."
                )