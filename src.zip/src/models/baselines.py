"""
baselines
=========

Naive baselines for the demand comparison table.
"""

import numpy as np
import pandas as pd
from eval.scorer import DemandScorer

__all__ = ["historical_median", "seasonal_naive"]


def seasonal_naive(
    y_hold: np.ndarray,
    y_naive_hold: np.ndarray,
    scorer: DemandScorer,
    p: float,
) -> dict:
    return scorer.calculate_all(y_hold, y_naive_hold, y_naive_hold, p=p)


def historical_median(
    X_train: pd.DataFrame,
    y_train: np.ndarray,
    X_hold: pd.DataFrame,
    y_hold: np.ndarray,
    y_naive_hold: np.ndarray,
    scorer: DemandScorer,
    p: float,
) -> dict:
    keys = ["hora", "dia_semana"]
    train_df = X_train[keys].copy()
    train_df["y"] = y_train
    medians = train_df.groupby(keys)["y"].median().rename("y_pred").reset_index()

    hold_keys = X_hold[keys].copy()
    hold_keys["_row"] = np.arange(len(hold_keys))
    merged = hold_keys.merge(medians, on=keys, how="left")

    global_median = float(np.median(y_train))
    merged["y_pred"] = merged["y_pred"].fillna(global_median)
    preds = merged.sort_values("_row")["y_pred"].to_numpy(dtype=np.float64)

    return scorer.calculate_all(y_hold, preds, y_naive_hold, p=p)